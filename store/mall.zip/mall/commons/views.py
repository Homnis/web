
from io import BytesIO

from django.shortcuts import render
from django.http import HttpResponse
from . import tools

# Create your views here.


def codes(request):
    img, code = tools.create_code(4)
    f = BytesIO()
    img.save(f, "png")  # 将图像保存在f IO对象中
    # 将验证码存入session 中， 以便别人验证
    request.session["codes"] = code
    return HttpResponse(f.getvalue(), "image/png")


# 主页
def index(request):
    goods_list, mt_list, wly_list = tools.getIndex()
    return render(request, "commons/index.html", {"goods_list": goods_list, "mt_list": mt_list, "wly_list": wly_list,})


def agree(request):
    return render(request, "commons/agree.html", {})
