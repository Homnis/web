﻿import hashlib
import hmac
import random, string


from django.conf import settings
# from mysite import settings

from PIL import Image, ImageDraw,ImageFont,ImageFilter
"""网易云手机验证码API测试"""

import hashlib
import random
import time
# noinspection PyCompatibility
from urllib import request, parse

# redis 缓存
from django.core.cache import cache
from goods import models


#  hmac md5加密

def getMD5ByHmac(value):
    salt = settings.MD5_SALT
    md5 = hmac.new(salt.encode("utf-8"), value.encode("utf-8"), "MD5")
    return md5.hexdigest()


# 获取验证码
def getRandomChar(count):
    # 生成随机字符串
    # string模块包含各种字符串，以下为小写字母加数字
    ran = string.ascii_lowercase + string.digits
    char = ''
    for i in range(count):
        char += random.choice(ran)
    return char


# 返回一个随机的RGB颜色
def getRandomColor():
    return (random.randint(50,150),random.randint(50,150),random.randint(50,150))


def create_code(count=4):
    # 创建图片，模式，大小，背景色
    img = Image.new('RGB', (120, 35), (255, 255, 255))
    #创建画布
    draw = ImageDraw.Draw(img)
    # 设置字体
    font = ImageFont.truetype('arial.ttf', 25)

    code = getRandomChar(count)
    # 将生成的字符画在画布上
    for t in range(count):
        draw.text((30*t+5, 0), code[t], getRandomColor(), font)

    # 生成干扰点
    for _ in range(random.randint(0, 50)):
        # 位置，颜色
        draw.point((random.randint(0, 120),random.randint(0, 30)), fill=getRandomColor())

    return img, code


"""网易云手机验证码API测试"""

class ServerAPI(object):
    """
     * 参数初始化
     * @param AppKey
     * @param AppSecret
    """
    def __init__(self):
        self.AppKey = ''  # 开发者平台分配的AppKey
        self.AppSecret = ''  # 开发者平台分配的AppSecret,可刷新
        self.CheckSum = ''
        self.CurTime = ''
        self.Nonce = ''   # 随机字符串最大128个字符，也可以小于该数

    def checkSumBuilder(self):
        """
             * API checksum校验生成
             * @param  void
             * @return CheckSum(对象私有属性)
        """
        charHex = '0123456789abcdef'

        for i in range(0, 10):
            index = random.randint(0, 10)
            self.Nonce += charHex[index]

        self.CurTime = int(time.time())  # 当前UTC时间戳，从1970年1月1日0点0 分0 秒开始到现在的秒数(String)
        join_string = self.AppSecret + self.Nonce + str(self.CurTime)

        self.CheckSum = hashlib.sha1(join_string.encode('utf-8')).hexdigest()  # SHA1(AppSecret + Nonce + CurTime),三个参数拼接的字符串，进行SHA1哈希计算，转化成16进制字符(String，小写)

    def postDataHttps(self, url, data):
        """
             * 使用urllib2发送post请求
             * @param  url     [请求地址]
             * @param  data    [array格式数据]
             * @return 请求返回结果(array)
        """
        self.checkSumBuilder()
        headers = {
            'AppKey': self.AppKey,
            'Nonce': self.Nonce,
            'CurTime': self.CurTime,
            'CheckSum': self.CheckSum,
            'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        }
        postdata = data

        req = request.Request(url, parse.urlencode(postdata).encode(encoding='UTF8'), headers=headers)
        res_data = request.urlopen(req)
        resp = res_data.read()
        return eval(resp)

    def sendSmsCode(self, mobile, deviceId=''):
        """
             * 发送短信验证码
             * @param  mobile       [目标手机号]
             * @param  deviceId     [目标设备号，可选参数]
             * @return result      [返回python dict 对象]
        """
        url = 'https://api.netease.im/sms/sendcode.action'
        data = dict({
            'mobile': mobile,
            'deviceId': deviceId
        })
        return self.postDataHttps(url, data)


# redis 缓存
def getIndex():
    goods_list = cache.get("goods_list")
    mt_list = cache.get("mt_list")
    wly_list = cache.get("wly_list")

    if goods_list is None:
        print("缓存中没有数据，从数据库中查询")
        goods_list = models.Goods.objects.filter().all().order_by("-price")[:5]
        cache.set("goods_list", goods_list, timeout=180)
    if mt_list is None:
        print("缓存中没有数据，从数据库中查询")
        mt = models.GoodsType.objects.get(name="茅台")
        mt_list = models.Goods.objects.filter(goodstype=mt).order_by("-count")[:12]
        cache.set("mt_list", mt_list, timeout=180)
    if wly_list is None:
        print("缓存中没有数据，从数据库中查询")
        wly = models.GoodsType.objects.get(name="五粮液")
        wly_list = models.Goods.objects.filter(goodstype=wly).order_by("-count")[:12]
        cache.set("wly_list", wly_list, timeout=180)
    return goods_list, mt_list, wly_list



if __name__ == '__main__':
    #
    # checkcode = ServerAPI()
    # res = checkcode.sendSmsCode('19903836366')
    # print(res)
    pass
