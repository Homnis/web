from django.shortcuts import render, redirect, reverse
from . import models
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_GET
from django.http import HttpResponse
from django.core.serializers import serialize
from store.models import Store


@login_required
def add(request, s_id):
    store = Store.objects.filter(pk=s_id).first()
    if request.method == "GET":
        if store.user == request.user:
            goodstypes = models.GoodsType.objects.filter(parent_id__isnull=True)
            return render(request, "goods/add.html", {"type1": goodstypes, "store_id": s_id})
        else:
            return redirect("/")
    else:
        name = request.POST.get("name")
        price = request.POST.get("price")
        stock = request.POST.get("stock")
        intro = request.POST.get("intro")
        type2_id = request.POST.get("type2")
        type2 = models.GoodsType.objects.filter(pk=type2_id).first()
        de_path = request.FILES.get("de_cover")
        paths = request.FILES.getlist("cover")
        # 先实例化商品， 再实例化商品图像
        goods = models.Goods(name=name, price=price, stock=stock, intro=intro, store=store, goodstype=type2)
        goods.save()
        if de_path:
            de_rimg = models.GoodsImage(path=de_path, status=True, intro=intro, goods=goods)
            de_rimg.save()
        if paths:
            for path in paths:
                goodsimage = models.GoodsImage(path=path, intro=intro, goods=goods)
                goodsimage.save()
        return redirect(reverse("store:detail", kwargs={"s_id": s_id}))  # todo


def detail(request, g_id):
    goods = models.Goods.objects.filter(pk=g_id).first()
    goodsImages = list(goods.goodsimage_set.all())
    de_img = "/static/upload/goods/default.png"
    comments = goods.comment_set.all()
    c_count = comments.count()


    for img in goodsImages:
        if img.status:
            de_img = img
            goodsImages.remove(img)
            break
    # print(type(goods.goodsimage_set.all()))
    return render(request, "goods/detail.html", {"goods": goods, "de_img": de_img,
                                                 "goods_images": goodsImages,
                                                 "comments": comments, "c_count": c_count})


@login_required
def update(request):
    return redirect("/")


@login_required
def delete(request):
    return redirect("/")


@require_GET
def findTypeByPId(request):
    parent_id = request.GET.get("parent_id")
    type2s = models.GoodsType.objects.filter(parent_id=parent_id)
    return HttpResponse(serialize("json", type2s))
