from django.shortcuts import render, redirect, reverse
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST, require_GET
from commons.models import China_add
from django.core.serializers import serialize
from django.http import HttpResponse,JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.forms.models import model_to_dict
from shopcart.models import ShopCart
from user.models import Address
from .models import Orders, orders_item
from django.core.paginator import Paginator
from user.models import Comment
from goods.models import Goods
from django.db import transaction


@require_GET
@login_required
# 订单确认
def confirm(request):
    scs = []
    if request.session.get("del_sess", False):
        scs = request.session["del_sess"]
        del request.session["del_sess"]
    else:
        s_ids = request.GET.getlist("s_id")
        for id in s_ids:
            if isinstance(id, int):
                sc = ShopCart.objects.get(pk=id)
            else:
                sc = ShopCart.objects.get(pk=int(id))
                new_count = request.GET.get("count_{}".format(id))
                if sc.count != new_count:
                    sc.count = new_count
                    sc.allTotal = int(sc.count)*int(sc.goods.price)
                    sc.save()
                scs.append(sc)

    type1 = China_add.objects.filter(area_parent_id__isnull=True)
    addresses = Address.objects.filter(user=request.user)
    request.session["sc_ids"] = scs
    return render(request, "orders/confirm.html", {"type1": type1, "scs": scs, "addresses": addresses})


@require_POST
@login_required
@csrf_exempt
# 添加地址的地址联动ajax
def add_new_add(request):
    pa1_id = request.POST.get("pa1_id")
    pAdd = China_add.objects.get(pk=pa1_id)
    type2s = China_add.objects.filter(area_parent_id=pAdd)
    allAddress = []
    for x in type2s:
        allAddress.append(model_to_dict(x))
    return JsonResponse(allAddress, safe=False)



@require_GET
@login_required
# 添加地址的地址联动ajax
def add_new_add2(request):
    pa2_id = request.GET.get("pa2_id")
    pa2 = China_add.objects.get(pk=pa2_id)
    type3s = China_add.objects.filter(area_parent_id=pa2)
    allAddress = []
    for x in type3s:
        allAddress.append(model_to_dict(x))
    return JsonResponse(allAddress, safe=False)


@login_required
# 切换默认地址
def change_ad_de(request, ad_id):
    addresses = Address.objects.filter(user=request.user)
    for ad in addresses:
        ad.is_default = 0
        if ad.id == int(ad_id):
            ad.is_default = 1
        ad.save()
    sc = request.session["sc_ids"]
    request.session["del_sess"]=sc
    del request.session["sc_ids"]
    return redirect("/orders/confirm/")


@login_required
# 删除地址
def delete(request, ad_id):
    addresses = Address.objects.filter(pk=ad_id)
    addresses.delete()
    sc = request.session["sc_ids"]
    request.session["del_sess"]=sc
    del request.session["sc_ids"]
    return redirect("/orders/confirm/")


# 订单生成
@require_POST
@transaction.atomic
def create(request):
    s_ids = request.session["sc_ids"]
    del request.session["sc_ids"]
    order_total = request.POST.get("order_total", False)
    order_addId = request.POST.get("order_addId", False)
    address = Address.objects.get(pk=order_addId)
    recv_address = address.province + address.area + address.street + address.desc
    # 生成订单
    save_point = transaction.savepoint()
    try:
        orders = Orders(user=request.user, recv_name=address.recv_name, recv_tel=address.recv_tel, \
                        recv_address=recv_address, all_price=order_total, remark="买酒就找任彦彪！"
                        )
        orders.save()
        #  订单明细
        for s_id in s_ids:
            shopcart = s_id

            items = orders_item(good_id=shopcart.goods.id, goods_img=shopcart.goods.goodsimage_set.all().first().path, \
                                goods_name=shopcart.goods.name, goods_price=shopcart.goods.price, \
                                goods_count = shopcart.count, goods_price_all=shopcart.allTotal, \
                                order=orders
                                )
            # 商品库存减少,销量增加
            goods = shopcart.goods
            goods.stock = int(shopcart.goods.stock)-int(shopcart.count)
            goods.count += int(shopcart.count)
            goods.save()
            if int(goods.stock) < 0:
                transaction.savepoint_rollback(save_point)
                return render(request, "orders/isSuccess.html", {"msg": "支付失败，库存不足"})
            # 购物车里删除这几条
            items.save()
        number = len(s_ids)
        for x in range(number):
            shopcart_del = s_ids[x]
            shopcart_del.delete()
        transaction.savepoint_commit(save_point)
        return render(request, "orders/isSuccess.html", {"msg": "订单支付成功！"})
    except Exception as e:
        transaction.savepoint_rollback(save_point)
        return render(request, "orders/isSuccess.html", {"msg": "订单支付失败！"})


@login_required
# 订单列表
def list(request):
    user = request.user
    orders = Orders.objects.filter(user=user).order_by("-create_time")

    pageNow = int(request.GET.get("pageNow", 1))
    # 每页显示的条数
    pageSize = 4
    # 获取分页对象
    paginator = Paginator(orders, pageSize)
    # 获取分页对象的列表，参数是当前页码
    page = paginator.page(pageNow)

    # 总页数
    num_pages = paginator.num_pages
    # 进行页码控制
    # 1.总页数<5, 显示所有页码
    # 2.当前页是前3页，显示1-5页
    # 3.当前页是后3页，显示后5页 10 9 8 7
    # 4.其他情况，显示当前页前2页，后2页，当前页
    if num_pages < 5:
        pages = range(1, num_pages + 1)
    elif pageNow <= 3:
        pages = range(1, 6)
    elif num_pages - pageNow <= 2:
        pages = range(num_pages - 4, num_pages + 1)
    else:
        pages = range(pageNow - 2, pageNow + 3)
    # 订单中还有没有评价的item
    com_list = []
    for order in page.object_list:
        for item in order.orders_item_set.all():
            goods = Goods.objects.get(pk=item.good_id)
            if Comment.objects.filter(goods=goods, user=request.user).count() == 0:
                com_list.append(order)
                break

    return render(request, "orders/list.html", {"page": page, "pageSize": pageSize, "pages": pages, "com_list": com_list})


@csrf_exempt
@require_POST
def find_goods(request, o_id):
    order = Orders.objects.get(pk=o_id)
    id_list = []
    for item in order.orders_item_set.all():
        goods = Goods.objects.get(pk=item.good_id)
        if Comment.objects.filter(goods=goods, user=request.user).count() == 0:
            id_list.append(item.goods_name)

    return HttpResponse("{}".format(id_list))


# 添加评论函数
@require_POST
def add_comment(request):
    goods_name = request.POST.get("goods")
    content = request.POST.get("content")
    rank = request.POST.get("rank")
    rank_path = "/static/upload/rank/defalut/star_{}.png".format(rank)
    goods = Goods.objects.get(name=goods_name)
    comment = Comment(content=content, goods=goods, user=request.user, rank=rank_path)
    comment.save()
    return redirect("/orders/list/")


