$(document).ready(function() {
    //注册验证
   // $(".login_form").validate({
   //      onfocusout: function(element) { 
   //          $(element).valid(); 
   //      },
   //      rules:{
   //          username:{
   //              required: true
   //          }
   //      },
   //      messages : {
   //           username:{
   //              required : "请输入用户名"
   //           }
   //      }
   //  });
});		