from django.apps import AppConfig


class ShopcartConfig(AppConfig):
    name = 'shopcart'
