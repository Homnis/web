from django.db import models

from django.contrib.auth.models import User
# Create your models here.


class Store(models.Model):
    # id
    id = models.AutoField(primary_key=True)
    # 店铺名称
    name = models.CharField(max_length=150, unique=True, verbose_name="店铺名称")
    # 店铺头像
    cover = models.ImageField(upload_to="static/upload/store_ava/", default="static/upload/store_ava/default.png", verbose_name="店铺头像")
    # 店铺描述
    intro = models.TextField(verbose_name="店铺描述")
    # 开店时间
    openTime = models.DateTimeField(auto_now_add=True, verbose_name="开店时间")
    # 店铺状态 0 正常营业 1 暂停营业 2 永久删除
    status = models.IntegerField(default=0, verbose_name="店铺状态")
    # 店主
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="店铺所属用户")

    class Meta:
        verbose_name = "商店"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name


