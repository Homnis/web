from django.db import models
from django.contrib.auth.models import User
from store.models import Store
from tinymce.models import HTMLField  # 富文本框
# Create your models here.


def upload_to(instance, filename):
    return '/'.join(["static/upload/goodstype/", instance.name, filename])


def upload_to1(instance, filename):
    return '/'.join(["static/upload/goods/", str(instance.goods.id), filename])


class GoodsType(models.Model):
    id = models.AutoField(primary_key=True)
    # 商品名称
    name = models.CharField(max_length=150, unique=True, verbose_name="商品类别名称")
    # 商品类的图片
    cover = models.ImageField(upload_to=upload_to, default="static/upload/goodstype/default.png", verbose_name="商品类配图")
    # 商品类的描述
    intro = HTMLField(verbose_name="商品类别描述")
    # 父级类型
    parent = models.ForeignKey('self', null=True, blank=True, verbose_name="父级类型", on_delete=models.CASCADE)

    class Meta:
        verbose_name = '商品类型'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name

class Goods(models.Model):
    id = models.AutoField(primary_key=True)
    # 商品名称
    name = models.CharField(max_length=255, verbose_name="商品名称")
    # 商品单价
    price = models.FloatField(verbose_name="商品单价")
    # 商品库存
    stock = models.IntegerField(verbose_name="商品库存")
    # 商品销量
    count = models.IntegerField(default=0, verbose_name="商品销量")
    # 商品生成时间
    creatTime = models.DateTimeField(auto_now_add=True, verbose_name="商品生成时间")
    # 商品简介
    intro = HTMLField(verbose_name="商品简介")
    # 商品所属商店
    store = models.ForeignKey(Store, on_delete=models.CASCADE, verbose_name="商品所属商店")
    # 商品类型
    goodstype = models.ForeignKey(GoodsType, on_delete=models.CASCADE, verbose_name="商品类型")


    class Meta:
        verbose_name = '商品'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name

class GoodsImage(models.Model):
    id = models.AutoField(primary_key=True)
    # 商品的图片存储路径
    path = models.ImageField(upload_to=upload_to1, default="static/upload/goods/default.png", verbose_name="商品图片")
    # 是否显示这个图片
    status = models.BooleanField(default=False, verbose_name="是否默认显示该图片")
    # 商品图片的描述
    intro = HTMLField(verbose_name="商品图片描述", null=True, blank=True)
    # 外键， 所属的产品
    goods = models.ForeignKey(Goods, on_delete=models.CASCADE, verbose_name="所属商品")

    class Meta:
        verbose_name = '商品配图'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.goods.name

