from django.conf.urls import url

from . import views

urlpatterns = [
    url(r"^code/$", views.codes, name="codes"),
    url(r"^agree/$", views.agree, name="agree"),
    url(r"^$", views.index, name="index")
]
