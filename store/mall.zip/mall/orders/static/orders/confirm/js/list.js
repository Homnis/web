
// 地址选择三级联动
$(function(){
    $("#type1").on("change",function(){
    var $data = $(this).val()
    if ($data == -1) {
        $("#type2").empty()
        return
    }
    $.ajax({
        url: "/orders/add_new_add/",
        type: "post",
        data: {"pa1_id": $data},
        success: function (data){
            $("#type2").empty()
            $("#type2").append("<option value='-1'>请选择</option>")
            for (var i = 0; i < data.length; i++) {
                var type = data[i];
                // console.info(type)
                $op = $("<option>");
                var type_pk = type.id
                $op.attr("value", type_pk);
//                $op.value = type.pk

                $op.text(type.area);
                $("#type2").append($op);
            }

        }
    });
    });


    $("#type2").on("change",function(){
    var $data = $(this).val()
    if ($data == -1) {
        $("#type3").empty()
        return
    } else{
        $("#save_10").removeProp("disabled");
    }

    $.ajax({
        url: "/orders/add_new_add2/",
        type: "get",
        data: {"pa2_id": $data},
        success: function(data){
            $("#type3").empty()
            for (var i2 = 0; i2 < data.length; i2++) {
            var type_1 = data[i2];
            var
            $op2 = $("<option>");

            $op2.attr("value", type_1.id);
            $op2.text(type_1.area);
            $("#type3").append($op2);


                                                     }

                                }



    });

    });

});

// 地址提交到页面
//
//$(function(){
//    $("#save_10").on("click", function(){
//            var recv_name = $("#recv_name").val();
//            var recv_number = $("#recv_number").val();
//            var province_id = $("#type1").val();
//            var city_id = $("#type2").val();
//            var area_id = $("#type3").val();
//            var street = $("#street").val();
//        $.ajax({
////            console.info(province)
//            url: "/user/add_address/",
//            type: "post",
//            data: {"recv_name": recv_name, "recv_number":recv_number, "province_id":province_id,
//                    "city_id":city_id, "area_id":area_id, "street":street
//                  },
//            success: function(data){
//                data = JSON.parse(data)
//
//
//            },
//
//        })
//
//    });
//
//
//});


