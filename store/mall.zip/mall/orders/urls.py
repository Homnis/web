from django.conf.urls import url

from . import views

urlpatterns = [
    url(r"^confirm/$", views.confirm, name="confirm"),
    url(r"^add_new_add/$", views.add_new_add, name="add_new_add"),
    url(r"^add_new_add2/$", views.add_new_add2, name="add_new_add2"),
    url(r"^create/$", views.create, name="create"),
    url(r"^(?P<ad_id>\d+)/change_ad_de/$", views.change_ad_de, name="change_ad_de"),
    url(r"^(?P<ad_id>\d+)/delete/$", views.delete, name="delete"),
    url(r"^list/$", views.list, name="list"),
    url(r"^add_comment/$", views.add_comment, name="add_comment"),
    url(r"^(?P<o_id>\d+)/find_goods/$", views.find_goods, name="find_goods"),
    # url(r"^detail/$", views.detail, name="detail"),
]
