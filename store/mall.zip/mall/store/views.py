from django.shortcuts import render, redirect, reverse
from django.contrib.auth.decorators import login_required
from .models import Store
from goods.models import Goods
# Create your views here.


@login_required
def add(request):
    if request.method == "GET":
        return render(request, "store/add.html", {})
    else:
        name = request.POST.get("name", False)
        cover = request.FILES.get("cover", False)
        intro = request.POST.get("intro", False)
        if name and cover and intro:
            store = Store(name=name, cover=cover, intro=intro, user= request.user)
            store.save()
            return redirect(reverse("store:detail", kwargs={"s_id": store.id}))
        else:
            return render(request, "store/add.html", {"msg": "请认真填写，不要有空项。"})



@login_required
def detail(request, s_id):
    if request.method == "GET":
        store = Store.objects.filter(pk=s_id).first()
        goods = Goods.objects.filter(store=store)
        if store:
            return render(request, "store/detail.html", {"store": store, "goods": goods})
        else:
            return redirect("/")


@login_required
def change(request, s_id, status):
    store = Store.objects.filter(pk=s_id).first()

    if store:
        if request.user.id != store.user.id:
            return redirect("/")
        else:

            store.status = int(status)
            store.save()
            if int(status) == 2:
                return redirect(reverse("store:s_list"))
            return render(request, "store/detail.html", {"store": store})
    else:
        return redirect("/")  # TODO


@login_required
def update(request, s_id):
    store = Store.objects.filter(pk=s_id).first()
    if request.method == "GET":
        if store:
            if request.user != store.user:
                return redirect("/")
            else:
                return render(request, "store/update.html", {"store":store})
        else:
            return redirect("/")  # TODO

    else:
        name = request.POST.get("name", False)
        cover = request.FILES.get("cover", False)
        intro = request.POST.get("intro", False)
        if name:
            store.name = name
        if cover:
            store.cover = cover
        if intro:
            store.intro = intro
        store.save()

        return redirect(reverse("store:detail", kwargs={"s_id": store.id}))



@login_required
def s_list(request):
    stores = Store.objects.filter(user=request.user)
    return render(request, "store/s_list.html", {"stores":stores})


