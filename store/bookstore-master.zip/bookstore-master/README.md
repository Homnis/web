# bookstore
使用Django编写一个书城电商网站，配合详细的教程。
