from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from .models import UserInfo, Address
from django.http import JsonResponse, HttpResponse
from django.core.serializers import serialize
from commons.models import China_add
from django.views.decorators.csrf import csrf_exempt
from django.forms.models import model_to_dict
# from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from mall import settings
from django.core.mail import send_mail
from commons import tools

# Create your views here.


# 手机ajax验证码的发送
@csrf_exempt
@require_POST
def phone_code(request, tel):
    try:
        checkcode = tools.ServerAPI()
        res = checkcode.sendSmsCode(tel)
        request.session["phone_code"] = res
        return JsonResponse({"success": True, "msg": "手机验证码发送成功！"})
    except:
        return JsonResponse({"success": False, "msg": "手机验证码发送失败！"})


# 激活函数
def active(request, token):
    try:
        ser = Serializer(settings.SECRET_KEY,3600)
        user_id = int(ser.loads(token)["confirm"])
        user = User.objects.get(pk=user_id)
        user.is_active = 1
        user.save()
        return redirect("/user/login/")
    except Exception as e:
        return HttpResponse("激活失败！请联系服务人员！")


#  邮箱注册
@require_POST
def register_email(request):
    username = request.POST.get("email").strip()
    password = request.POST.get("passwordB").strip()
    re_password = request.POST.get("passwordB2").strip()
    nickname = request.POST.get("nickname").strip()
    if re_password == password:
        if User.objects.filter(username=username):

            return render(request, "user/register.html", {"msg": "注册失败用户名已存在"})
        else:
            if UserInfo.objects.filter(nickname=nickname):

                return render(request, "user/register.html", {"msg": "注册失败，昵称已经存在！"})
            else:
                # 保存用户
                user = User.objects.create_user(username=username, email=username, password=password, is_active=0)
                userinfo = UserInfo(nickname=nickname, user=user)
                user.save()
                userinfo.save()
                """
                    发送激活邮件
                """
                #  加密身份信息  ( 盐值，失效时间 )
                ser = Serializer(settings.SECRET_KEY, 3600)
                info = {"confirm": user.id}
                token = ser.dumps(info).decode()

                # 发邮件
                subject = '任彦彪商城欢迎信息'  # 主题
                message = ""  # 信息内容
                sender = settings.EMAIL_FROM  # 发件人
                receiver = [username]  # 收件人
                #  html 内容
                html_message = "<h1>{}, 欢迎您成为彪彪购酒网的会员</h1>请点击下面的链接激活您的账户<br/>" \
                               "<a href='http://192.168.14.3:8000/user/active/{}'>" \
                               "http://192.168.14.3:8000/user/active/{}</a>".format(username, token, token)
                send_mail(subject, message, sender, receiver, html_message=html_message)

                return redirect("/user/login/")
    else:

        return render(request, "user/register.html", {"msg": "注册失败两次密码不一致"})


# 手机注册
def register(request):
    if request.method == "GET":
        return render(request, "user/register.html", {})
    else:
        tel_code = request.POST.get("tel_code").strip()
        try:
            if int(tel_code) == int(request.session["phone_code"]["obj"]):
                username = request.POST.get("phone").strip()
                password = request.POST.get("passwordA").strip()
                re_password = request.POST.get("passwordA2").strip()
                nickname = request.POST.get("nickname").strip()
                if re_password == password:
                    if User.objects.filter(username=username):

                        return render(request, "user/register.html", {"msg": "注册失败手机号已存在"})
                    else:
                        if UserInfo.objects.filter(nickname=nickname):

                            return render(request, "user/register.html", {"msg": "注册失败，昵称已经存在！"})
                        else:
                            # 保存用户
                            user = User.objects.create_user(username=username, password=password)
                            userinfo = UserInfo(nickname=nickname, user=user, tel=username)
                            user.save()
                            userinfo.save()
                            del request.session["phone_code"]

                            return redirect("/user/login/")
                else:

                    return render(request, "user/register.html", {"msg": "注册失败两次密码不一致"})

            else:
                return render(request, "user/register.html", {"msg": "注册失败验证码不正确！"})
        except:
            return render(request, "user/register.html", {"msg": "注册失败验证码不正确！"})



# 验证用户名是否可用的ajax接口
@csrf_exempt
@require_POST
def checkusername(request):
    username = request.POST.get("username")
    try:
        User.objects.get(username=username)
        return JsonResponse({"success": False, "msg": "用户名已存在"})
    except:
        return JsonResponse({"success": True, "msg": "用户名可用"})


# 验证昵称是否可用的ajax接口
@csrf_exempt
@require_POST
def checknickname(request):
    nickname = request.POST.get("nickname")
    if UserInfo.objects.filter(nickname=nickname):
        return JsonResponse({"success": False, "msg": "昵称不可用"})
    else:
        return JsonResponse({"success": True, "msg": "昵称可用"})


# 用户登录函数！！！
def user_login(request):
    if request.method == "GET":
        next_url = request.GET.get("next", "/")
        return render(request, "user/login.html", {"next_url": next_url})
    else:
        code = request.POST.get("code").strip()
        username = request.POST.get("username").strip()
        password = request.POST.get("password").strip()
        next_url = request.POST.get("next", "/")

        if next_url == "":
            next_url = "/"
        # 验证用户名和密码
        if code == request.session["codes"]:

            user = User.objects.filter(username=username).first()
            if user:
                # 判断状态是否激活
                if user.is_active:
                    user = authenticate(username=username, password=password)
                    if user:
                        # 将验证用户信息保存在request
                        login(request, user)

                        return redirect(next_url)

                    else:
                        return render(request, "user/login.html", {"msg": "用户名或密码错误!"})


                else:
                    return render(request, "user/login.html", {"msg": "用户未激活，请去您的邮箱激活!"})
            else:
                return render(request, "user/login.html", {"msg": "用户名或密码错误!"})
        else:
            return render(request, 'user/login.html', {"msg": "验证码错误！"})


# 登出函数
@login_required
def user_logout(request):
    logout(request)
    return redirect("/")


# 用户详情
@login_required
def detail(request):
    return render(request, "user/detail.html", {})


# 订单页添加地址
@login_required
@require_POST
def add_address(request):
    recv_name = request.POST.get("recv_name")
    recv_tel = request.POST.get("recv_number")
    province_id = request.POST.get("province_id")
    city_id = request.POST.get("city_id")
    area_id = request.POST.get("area_id")
    street = request.POST.get("street")
    user = request.user
    province =China_add.objects.get(pk=province_id).area
    city =China_add.objects.get(pk=city_id).area
    area =China_add.objects.get(pk=area_id).area

    address = Address(recv_name=recv_name, recv_tel=recv_tel, province=province, city=city, area=area, \
                      street=street, desc=street, user=user)
    address.save()
    sc = request.session["sc_ids"]
    request.session["del_sess"] = sc
    del request.session["sc_ids"]
    # address_list = Address.objects.filter(user=request.user)
    # address = model_to_dict(address)

    # return JsonResponse(address, safe=True)
    return redirect("/orders/confirm/")


# 更新个人信息
@login_required
def update(request):
    if request.method == "GET":

        return render(request, "user/update.html", {})
    else:
        user = request.user
        avatar = request.FILES.get("avatar", False)
        print(avatar)
        if avatar:
            user.userinfo.avatar = avatar
        email = request.POST.get("email", False)
        print(email)
        if email:
            user.email = email
        tel = request.POST.get("tel", False)
        print(tel)
        if tel:
            user.userinfo.tel = tel
        gender = request.POST.get("sex", False)
        print(gender)
        if gender:

            user.userinfo.gender = gender
        user.save()
        user.userinfo.save()
        return redirect("/user/detail/")


# 更换密码
@login_required()
def change_pass(request):
    if request.method == "GET":
        return render(request, "user/change_pass.html", {})
    else:
        old_pass = request.POST.get("old_pass").strip()
        new_pass = request.POST.get("new_pass").strip()
        re_pass = request.POST.get("re_pass").strip()
        user = authenticate(username=request.user, password=old_pass)
        if user:
            if len(new_pass) > 5 and new_pass == re_pass:
                user.set_password(new_pass)
                user.save()
                return redirect("/user/login/")
            else:
                return render(request, "user/change_pass.html", {"msg": "密码不符合规定！"})
        else:
            return render(request, "user/change_pass.html", {"msg": "旧密码不正确！"})


# 地址管理
@login_required()
def address_manage(request):
    if request.method == "GET":
        add_addresses = Address.objects.filter(user=request.user)[:6]

        type1 = China_add.objects.filter(area_parent_id__isnull=True)
        return render(request, "user/address_manage.html", {"type1": type1, "addresses": add_addresses})
    else:
        recv_name = request.POST.get("recv_name")
        recv_tel = request.POST.get("recv_number")
        province_id = request.POST.get("province_id")
        city_id = request.POST.get("city_id")
        area_id = request.POST.get("area_id")
        street = request.POST.get("street")
        user = request.user
        province = China_add.objects.get(pk=province_id).area
        city = China_add.objects.get(pk=city_id).area
        area = China_add.objects.get(pk=area_id).area

        address = Address(recv_name=recv_name, recv_tel=recv_tel, province=province, city=city, area=area, \
                          street=street, desc=street, user=user)
        address.save()

        return redirect("/user/address_manage/")


@login_required
# 切换默认地址
def change_ad_de(request, ad_id):
    addresses = Address.objects.filter(user=request.user)
    for ad in addresses:
        ad.is_default = 0
        if ad.id == int(ad_id):
            ad.is_default = 1
        ad.save()
    return redirect("/user/address_manage/")


@login_required
# 删除地址
def delete(request, ad_id):

    addresses = Address.objects.filter(pk=ad_id).first()
    if addresses.user == request.user:
        addresses.delete()
    return redirect("/user/address_manage/")