from django.db import models
from datetime import datetime
# Create your models here.


class China_add(models.Model):
    id = models.AutoField(primary_key=True)
    # 区域名称
    area = models.CharField(max_length=200, verbose_name="区域名称")
    # 区域代码
    area_code = models.CharField(max_length=200, verbose_name="区域代码")
    # 区域简称
    area_short = models.CharField(max_length=200, null=True, verbose_name="区域简称")
    # 是否热门(0:否、1:是)
    area_is_hot = models.IntegerField(null=True, verbose_name="是否热门")
    # 区域序列
    area_sequence = models.IntegerField(null=True, verbose_name="区域序列")
    # 上级主键
    area_parent_id = models.ForeignKey("self", null=True, blank=True, verbose_name="上级主键")
    # 初始时间
    init_date = models.DateTimeField(default=datetime.now(), verbose_name="初始时间")
    # 初始地址
    init_addr = models.CharField(max_length=100, verbose_name="初始地址")





