from django.contrib import admin
from goods.models import Goods, GoodsImage, GoodsType
# Register your models here.


class GoodsImageInline(admin.TabularInline):
    model = GoodsImage


class GoodsAdmin(admin.ModelAdmin):
    list_display = ("name", "price", "stock")
    inlines = [GoodsImageInline]
    class Media:
        js = (
            "/static/tiny_mce/tiny_mce.js"
        )



admin.site.register(Goods, GoodsAdmin)
admin.site.register([GoodsType])

