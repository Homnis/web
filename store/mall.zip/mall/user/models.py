from django.db import models
from goods.models import Goods
from django.contrib.auth.models import User
# Create your models here.


class UserInfo(models.Model):
    # 用户id
    id = models.AutoField(primary_key=True)
    # 用户昵称
    nickname = models.CharField(max_length=150, unique=True, verbose_name="用户昵称")
    # 用户年龄
    age = models.IntegerField(default=18, verbose_name="年龄")
    # 用户性别
    gender = models.CharField(max_length=50, default="男", verbose_name="性别")
    # 用户头像
    avatar = models.ImageField(upload_to="static/upload/avatars/", default="static/upload/avatars/default.png", verbose_name="头像")
    # 联系方式
    tel = models.CharField(max_length=200, default="15038063622", verbose_name="电话")
    # 和系统内置的用户管理一对一
    user = models.OneToOneField(User, on_delete=models.CASCADE, verbose_name="用户")


class Address(models.Model):
    id = models.AutoField(primary_key=True)
    # 收货人
    recv_name = models.CharField(max_length=100, verbose_name="收货人")
    # 收货人的电话号码
    recv_tel = models.CharField(max_length=20, verbose_name="收货人的电话号码")
    # 收货人的省份
    province = models.CharField(max_length=100, verbose_name="收货人的省份")
    # 城市
    city = models.CharField(max_length=100, verbose_name="收货人的城市")
    # 县区
    area = models.CharField(max_length=100, verbose_name="收货人的县区")
    # 街道
    street = models.CharField(max_length=255, verbose_name="收货人的街道")
    # 描述
    desc = models.CharField(max_length=255, verbose_name="详细地址")
    # 是否是默认地址
    is_default = models.BooleanField(default=False, verbose_name="是否是默认地址")
    # 地址所属的用户
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="地址的所属用户")


def upload_to(instance, filename):
    return '/'.join(["static/upload/rank/", str(instance.goods.id), filename])


# 评论
class Comment(models.Model):
    id = models.AutoField(primary_key=True)
    # 内容
    content = models.CharField(max_length=255, verbose_name="评论内容")
    # 评分
    rank = models.ImageField(upload_to=upload_to, verbose_name="评分等级")
    # 发表时间
    pub_time = models.DateTimeField(auto_now_add=True, verbose_name="发表时间")
    # 发表用户
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="发表用户")
    # 所属商品
    goods = models.ForeignKey(Goods, on_delete=models.CASCADE, verbose_name="所属商品")

