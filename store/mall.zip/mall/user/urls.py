from django.conf.urls import url

from . import views

urlpatterns = [
    url(r"^register/$", views.register, name="register"),
    url(r"^register_email/$", views.register_email, name="register_email"),
    url(r"^login/$", views.user_login, name="login"),
    url(r"^logout/$", views.user_logout, name="logout"),
    url(r"^checkusername/$", views.checkusername, name="checkusername"),
    url(r"^checknickname/$", views.checknickname, name="checknickname"),
    url(r"^add_address/$", views.add_address, name="add_address"),
    url(r"^detail/$", views.detail, name="detail"),
    url(r"^update/$", views.update, name="update"),
    url(r"^phone_code/(?P<tel>\d+)/$", views.phone_code, name="phone_code"),
    url(r"^change_pass/$", views.change_pass, name="change_pass"),
    url(r"^address_manage/$", views.address_manage, name="address_manage"),
    url(r"^(?P<ad_id>\d+)/change_ad_de/$", views.change_ad_de, name="change_ad_de"),
    url(r"^(?P<ad_id>\d+)/delete/$", views.delete, name="delete"),
    url(r"^active/(?P<token>.*)/$", views.active, name="active"),

]
